//
//  SecondViewController.m
//  NavigationBarSample
//
//  Created by CWC on 17/9/21.
//  Copyright © 2017年 YiJiang Chen. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad{

    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor cyanColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
//    [self.navigationController.navigationBar setTranslucent:NO];
}

- (void)didReceiveMemoryWarning{

    [super didReceiveMemoryWarning];
    
}

@end
