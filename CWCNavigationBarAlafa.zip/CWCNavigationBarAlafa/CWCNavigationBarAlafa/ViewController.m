//
//  ViewController.m
//  CWCNavigationBarAlafa
//
//  Created by CWC on 17/9/21.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate>
/**
 *  视图
 */
@property (nonatomic, strong) UITableView *mytableView;
/**
*  <#注释#>
*/
@property (nonatomic, assign) CGFloat halfHeight;
/**
 *  <#注释#>
 */
@property (nonatomic, strong) UIImageView *imageView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.title = @"naviBar测试";
    
//    [self addHeaderView];
    
    [self.view addSubview:self.mytableView];
    
    _halfHeight = [UIScreen mainScreen].bounds.size.height * 0.5 - 64;
    [_mytableView setContentInset:UIEdgeInsetsMake(_halfHeight, 0, 0, 0)];
    
    
    
    
}

- (void)addHeaderView{

    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-100)/2, 64, 100, 100)];
    
    CAShapeLayer *maskLayer = [CAShapeLayer layer];
//    maskLayer.path = [UIBezierPath bezierPathWithOvalInRect:imageView.bounds].CGPath;
    maskLayer.fillColor = [UIColor blackColor].CGColor;
    maskLayer.strokeColor = [UIColor redColor].CGColor;
    
    maskLayer.frame = CGRectMake(0, 0, imageView.bounds.size.width, imageView.bounds.size.height);
    maskLayer.contentsCenter = CGRectMake(0.5, 0.5, 0.1, 0.1);
    maskLayer.contentsScale = [UIScreen mainScreen].scale;
    maskLayer.contents = (id)[UIImage imageNamed:@"right.png"].CGImage;
    
    imageView.layer.mask = maskLayer;
    imageView.image = [UIImage imageNamed:@"bikaqiu.png"];
    self.imageView = imageView;
    
    [self.view addSubview:imageView];
    
    
}

- (void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;//导航栏的背景色是黑色, 字体为白色
    [self scrollViewDidScroll:self.mytableView];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];//用于去除导航栏的底线，也就是周围的边线
    
}

- (void)viewWillDisappear:(BOOL)animated{

    [super viewWillDisappear:animated];
    
    [[[self.navigationController.navigationBar subviews] objectAtIndex:0] setAlpha:1];
}

- (void)viewDidLayoutSubviews{

    [super viewDidLayoutSubviews];
    
    NSLog(@"===%@",NSStringFromCGRect(self.view.frame));
   
    NSLog(@"-------%f",self.mytableView.contentInset.top);
    
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
    CGFloat offsetY = scrollView.contentOffset.y;
    NSLog(@"oooooo%f",offsetY);
    if (offsetY >= - _halfHeight-64) {
        CGFloat alpha = MIN(1, (_halfHeight + offsetY + 64)/(_halfHeight+64));
        
        //这里需要区分，在translicent 切换值时，偏移量相差64
        if (self.navigationController.navigationBar.translucent && offsetY >= -64) {
            alpha = 1;
        }
        
        [[[self.navigationController.navigationBar subviews] objectAtIndex:0] setAlpha:alpha];
        
        
        
        if (alpha == 1) {
            [self.navigationController.navigationBar setTranslucent:NO];
            
        }else{
            
            [self.navigationController.navigationBar setTranslucent:YES];
        }
        
    } else {
        
        [self.navigationController.navigationBar setTranslucent:YES];
        [[[self.navigationController.navigationBar subviews] objectAtIndex:0] setAlpha:0];
        
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 20;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 60;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [self.mytableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = @"naviBar测试";
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self.navigationController pushViewController:[[SecondViewController alloc] init] animated:YES];
    
}

- (UITableView *)mytableView{

    if (!_mytableView) {
        _mytableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _mytableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _mytableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ceshi.jpg"]];
        _mytableView.delegate = self;
        _mytableView.dataSource = self;
    }
    return _mytableView;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
