//
//  UIViewController+NavigationBar.m
//  NavigationBarSample
//
//  Created by CWC on 17/9/21.
//  Copyright © 2017年 YiJiang Chen. All rights reserved.
//

#import "UIViewController+NavigationBar.h"
#import "ViewController.h"
#import <objc/runtime.h>

@implementation UIViewController (NavigationBar)

+ (void)load{

    Method viewWillAppear = class_getInstanceMethod(self, @selector(viewWillAppear:));
    Method logViewWillAppear = class_getInstanceMethod(self, @selector(logViewWillAppear:));
    
    method_exchangeImplementations(viewWillAppear, logViewWillAppear);
}

- (void)logViewWillAppear:(BOOL)animated{

    [self logViewWillAppear:animated];
    
    if ([self isKindOfClass:[ViewController class]]) {
        [self.navigationController.navigationBar setTranslucent:YES];
    }else{
    
        [self.navigationController.navigationBar setTranslucent:NO];
    }
    
}

@end
