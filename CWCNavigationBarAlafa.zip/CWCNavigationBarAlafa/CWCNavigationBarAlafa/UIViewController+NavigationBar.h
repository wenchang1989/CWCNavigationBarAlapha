//
//  UIViewController+NavigationBar.h
//  NavigationBarSample
//
//  Created by CWC on 17/9/21.
//  Copyright © 2017年 YiJiang Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (NavigationBar)

@end
